package com.grandline.focus

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class FocusAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var unallowedRunnable: Runnable? = null

    private val shortsViewIds = listOf(
        "com.google.android.youtube:id/reel_player_page_container",
        "com.google.android.youtube:id/reel_watch_fragment_root",
        "com.google.android.youtube:id/reel_recycler",
        "com.google.android.youtube:id/shorts_video_title"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !FocusState.isRunning || FocusState.isPaused || FocusState.streakBroken) return
        val pkg = event.packageName?.toString() ?: return

        // Ignore our own app and system UI (notification shade / keyboard)
        if (pkg == packageName || pkg == "com.android.systemui" || pkg.contains("inputmethod")) {
            cancelGraceTimer()
            return
        }

        // Check YouTube Shorts immediately inside the YouTube app
        if (pkg == "com.google.android.youtube") {
            cancelGraceTimer()
            val root = rootInActiveWindow ?: return
            if (isYouTubeShortsOpen(root)) {
                triggerBreak("You opened YouTube Shorts!")
            }
            return
        }

        // Allowed app? Keep streak safe
        if (FocusState.allowedPackages.contains(pkg)) {
            cancelGraceTimer()
            return
        }

        // Unallowed app: start 5-second grace timer
        if (unallowedRunnable == null) {
            val r = Runnable {
                if (FocusState.isRunning && !FocusState.isPaused && !FocusState.streakBroken) {
                    triggerBreak("You opened an unallowed app past the 5s grace window.")
                }
            }
            unallowedRunnable = r
            handler.postDelayed(r, 5000L)
        }
    }

    private fun isYouTubeShortsOpen(root: AccessibilityNodeInfo): Boolean {
        for (id in shortsViewIds) {
            val found = root.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) return true
        }
        return false
    }

    private fun triggerBreak(reason: String) {
        cancelGraceTimer()
        FocusState.streakBroken = true
        FocusState.isPaused = true
        FocusTimerService.updateNotification(this, FocusState.remainingFormatted, true, reason)
        FocusState.onStreakBrokenCallback?.invoke(reason)
    }

    private fun cancelGraceTimer() {
        unallowedRunnable?.let { handler.removeCallbacks(it) }
        unallowedRunnable = null
    }

    override fun onInterrupt() {
        cancelGraceTimer()
    }
}
