package com.grandline.focus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class FocusTimerService : Service() {

    companion object {
        const val CHANNEL_ID = "grand_line_focus_timer"
        const val NOTIF_ID = 1001
        const val ACTION_UPDATE = "com.grandline.focus.UPDATE"
        const val ACTION_STOP = "com.grandline.focus.STOP"
        const val EXTRA_TIME = "extra_time"
        const val EXTRA_BROKEN = "extra_broken"
        const val EXTRA_REASON = "extra_reason"

        fun updateNotification(context: Context, timeText: String, broken: Boolean, reason: String = "") {
            val intent = Intent(context, FocusTimerService::class.java).apply {
                action = ACTION_UPDATE
                putExtra(EXTRA_TIME, timeText)
                putExtra(EXTRA_BROKEN, broken)
                putExtra(EXTRA_REASON, reason)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FocusTimerService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val timeText = intent?.getStringExtra(EXTRA_TIME) ?: FocusState.remainingFormatted
        val broken = intent?.getBooleanExtra(EXTRA_BROKEN, FocusState.streakBroken) ?: false
        val reason = intent?.getStringExtra(EXTRA_REASON) ?: ""

        val notification = buildNotification(timeText, broken, reason)
        startForeground(NOTIF_ID, notification)
        return START_STICKY
    }

    private fun buildNotification(timeText: String, broken: Boolean, reason: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (broken) {
            "You broke your streak!"
        } else {
            "Grand Line Focus · Streak Not Broken"
        }

        val body = if (broken) {
            if (reason.isNotBlank()) "$reason · Timer paused at $timeText" else "Distraction detected · Timer paused at $timeText"
        } else {
            "Time left: $timeText · Stay locked in"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setOngoing(!broken)
            .setOnlyAlertOnce(!broken)
            .setPriority(if (broken) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pi)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Study Timer & Streak Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Shows your live study countdown and streak status"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
