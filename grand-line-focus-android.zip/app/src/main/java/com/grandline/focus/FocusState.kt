package com.grandline.focus

object FocusState {
    @Volatile var isRunning: Boolean = false
    @Volatile var isPaused: Boolean = false
    @Volatile var streakBroken: Boolean = false
    @Volatile var remainingFormatted: String = "03:00:00"
    @Volatile var allowedPackages: Set<String> = setOf("com.google.android.youtube")
    @Volatile var onStreakBrokenCallback: ((String) -> Unit)? = null
}
