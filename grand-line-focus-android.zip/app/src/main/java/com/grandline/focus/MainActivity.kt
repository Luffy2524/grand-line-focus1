package com.grandline.focus

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request Android 13+ notification permission so the live timer shows in the notification panel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")

        FocusState.onStreakBrokenCallback = { reason ->
            runOnUiThread {
                val safe = reason.replace("'", "\'")
                webView.evaluateJavascript("window.onNativeStreakBroken && window.onNativeStreakBroken('$safe');", null)
            }
        }
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun getInstalledApps(): String {
            val pm = packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val apps = pm.queryIntentActivities(mainIntent, 0)
            val arr = JSONArray()
            val seen = HashSet<String>()
            for (ri in apps) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = ri.loadLabel(pm)?.toString() ?: pkg
                val obj = JSONObject()
                obj.put("id", pkg)
                obj.put("name", label)
                obj.put("cat", if (pkg.contains("instagram") || pkg.contains("snapchat")) "Distraction" else "Installed App")
                arr.put(obj)
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun setAllowedApps(jsonArrayStr: String) {
            try {
                val arr = JSONArray(jsonArrayStr)
                val set = HashSet<String>()
                for (i in 0 until arr.length()) {
                    set.add(arr.getString(i))
                }
                FocusState.allowedPackages = set
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun updateTimerNotification(timeText: String, running: Boolean, paused: Boolean, broken: Boolean, reason: String) {
            FocusState.isRunning = running
            FocusState.isPaused = paused
            FocusState.streakBroken = broken
            FocusState.remainingFormatted = timeText
            if (running || broken) {
                FocusTimerService.updateNotification(this@MainActivity, timeText, broken, reason)
            } else {
                FocusTimerService.stop(this@MainActivity)
            }
        }

        @JavascriptInterface
        fun openYouTubeChannel(url: String) {
            runOnUiThread {
                try {
                    val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        setPackage("com.google.android.youtube")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(ytIntent)
                } catch (_: Exception) {
                    val fallback = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(fallback)
                }
            }
        }

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }
    }
}
