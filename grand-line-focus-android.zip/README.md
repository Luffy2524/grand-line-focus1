# Grand Line Focus — Native Android APK Project

Created by Monkey D. Luffy

## Features Included
- **Live Android Notification-Panel Timer** (`FocusTimerService`): Shows your running countdown and `Streak Not Broken`, flipping to `You broke your streak!` if distraction is detected.
- **YouTube Shorts & Unallowed-App Guard** (`FocusAccessibilityService`): 5-second return grace window for unallowed apps, and instant detection if YouTube Shorts is opened inside the YouTube app.
- **Real Installed-App Picker** (`MainActivity.kt`): Lists every launcher app installed on your Android device.
- **Direct Native YouTube App Launcher**: Opens saved teacher channels straight in the official YouTube app.
- **Automatic GitHub Actions Cloud APK Builder** (`.github/workflows/build-apk.yml`): Compiles `app-debug.apk` automatically when uploaded to GitHub.

## After Installing the APK on Android
1. Allow **Notifications** when prompted so the live timer appears in your notification shade.
2. Go to **Android Settings → Accessibility → Installed apps → Grand Line Focus Shorts & App Guard** and turn it **ON** to enable YouTube Shorts and unallowed-app detection.
